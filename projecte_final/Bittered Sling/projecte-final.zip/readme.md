# A tenir en compte
* Perquè funcioni bé, la web ha d'esta hostejada en un servidor local per exemple, ja que sino no em deixava fer les request a la API.
* Els JSON server el faig servir només per emmagatzemar dades dels usuaris i està hostejat en el següent URL:
  * Github repo: https://github.com/BielAltimira/bittered-sling-json-server
  * JSON server: https://bittered-sling-json-server-production.up.railway.app/
* Podràs veure que he intentat aplicar el màxim de coses apreses: JQuery, bootstrap, JS, CSS propi, tutorials, Local Storage, Axios...i tota la web funciona perfectament, encara que, per contra, el codi potser no es molt net.
* Finalment, he mirat d'organitzar tot el sistema de fitxers per pagines i elements, ja que si no, en un sol fitxer quedaven masses línies.